import React from 'react';
import { useLocation } from 'react-router-dom';

const ReviewPage = () => {
  const location = useLocation();
  const { extractedInfo } = location.state || { extractedInfo: {} };

  return (
    <div>
      <h1>Review Your Cover Letter</h1>
      <h2>Extracted Text:</h2>
      <pre>{extractedInfo.text}</pre>
      <h2>Generated Cover Letter:</h2>
      <pre>{extractedInfo.coverLetter}</pre>
    </div>
  );
};

export default ReviewPage;
