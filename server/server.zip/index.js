const express = require('express');
const multer = require('multer');
const pdfParse = require('pdf-parse');
const Tesseract = require('tesseract.js');
const { Readable } = require('stream');
const { OpenAI } = require('openai');
require('dotenv').config();

const app = express();
const port = 5000;

// Set up storage for multer
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Middleware to handle JSON requests
app.use(express.json());
const cors = require('cors');
app.use(cors());

// Convert buffer to readable stream
const bufferToStream = (buffer) => {
  const readable = new Readable();
  readable._read = () => {}; // _read is required but you can noop it
  readable.push(buffer);
  readable.push(null);
  return readable;
};

// Function to extract text from a PDF file using pdf-parse
const extractTextFromPDF = async (buffer) => {
  try {
    const data = await pdfParse(buffer);
    return data.text;
  } catch (error) {
    throw new Error('Failed to extract text from PDF');
  }
};

// Function to extract text from images using Tesseract
const extractTextFromImage = async (buffer) => {
  return new Promise((resolve, reject) => {
    Tesseract.recognize(
      bufferToStream(buffer),
      'eng',
      {
        logger: info => console.log(info) // Optional: Log progress
      }
    ).then(({ data: { text } }) => resolve(text))
      .catch(reject);
  });
};

// Function to generate cover letter using OpenAI
const generateCoverLetter = async (text) => {
  const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
  });

  const prompt = `Generate a professional cover letter based on the following information extracted from the resume:\n\n${text}`;

  try {
    const response = await openai.completions.create({
      model: 'gpt-3.5-turbo', // Updated model
      prompt: prompt,
      max_tokens: 500,
    });

    return response.choices[0].text;
  } catch (error) {
    console.error('Error generating cover letter:', error.response ? error.response.data : error.message);
    if (error.response && error.response.status === 429) {
      throw new Error('Quota exceeded. Please check your OpenAI plan and billing details.');
    }
    throw new Error('Failed to generate cover letter');
  }
};

// Endpoint for extracting information from the uploaded file
app.post('/extract_info', upload.single('file'), async (req, res) => {
  console.log('Received file upload request');
  try {
    const file = req.file;
    if (!file) {
      console.log('No file uploaded');
      return res.status(400).json({ error: 'No file uploaded' });
    }

    console.log('File uploaded:', file.originalname);

    let extractedText = '';

    if (file.mimetype === 'application/pdf') {
      extractedText = await extractTextFromPDF(file.buffer);
    } else if (file.mimetype.startsWith('image/')) {
      extractedText = await extractTextFromImage(file.buffer);
    } else {
      console.log('Unsupported file type');
      return res.status(400).json({ error: 'Unsupported file type' });
    }

    console.log('Extracted text:', extractedText);

    try {
      const coverLetter = await generateCoverLetter(extractedText);

      res.json({
        message: 'File uploaded and information extracted successfully',
        extracted_info: {
          text: extractedText,
          coverLetter: coverLetter.trim(),
        }
      });
    } catch (error) {
      console.error('Error generating cover letter:', error);
      if (error.message.includes('Quota exceeded')) {
        res.status(429).json({ error: 'Quota exceeded. Please check your OpenAI plan and billing details.' });
      } else {
        res.status(500).json({ error: 'Failed to generate cover letter. Please try again.' });
      }
    }
  } catch (error) {
    console.error('Error extracting information:', error);
    res.status(500).json({ error: 'Failed to extract information from the file. Please try again.' });
  }
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});